package Utils.Enums;

public enum Domaine {
    Génie_civil, Electromecanique,
    Informatique, Telecommunication,Business
}
