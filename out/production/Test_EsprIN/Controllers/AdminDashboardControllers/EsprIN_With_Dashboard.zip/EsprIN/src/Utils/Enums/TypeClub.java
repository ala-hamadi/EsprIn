package Utils.Enums;

public enum  TypeClub {
    Association , Interne,Junior_entreprise
}
