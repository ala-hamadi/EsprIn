package Utils.Enums;

public enum OffreCategorie {
    Stage, Alternance, Offre_De_Travail
}
