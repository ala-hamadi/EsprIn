package Utils;

import Modules.User;

import java.io.Serializable;

public class UserSerializableData implements Serializable {
    public long userId;
}
