package Utils.Enums;

public enum  CategoryPost {
    Lost_and_Found, Covoiturage, Meme, Suggestion, Default
}
