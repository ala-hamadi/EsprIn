package Utils.Enums;

public enum AnnounceDestination {
    Tout,Etudiants, Professeur,Clubs
}
