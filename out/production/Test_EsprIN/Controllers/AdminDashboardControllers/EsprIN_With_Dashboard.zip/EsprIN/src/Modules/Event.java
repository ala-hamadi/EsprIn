package Modules;

import Utils.Enums.State;

import java.sql.Date;
import java.sql.Timestamp;

public class Event {

    private int idEvent;
    private  String TitleEvent;
    private String Description;
    private String ImgURL;
    private long idOrganizer;
    private String EventLocal;
    private int nbrParticipant;
    private State state;
    private Date DateEventDeb;
    private Date DateEventFin;

    public long getIdOrganizer() {
        return idOrganizer;
    }

    public void setIdOrganizer(long idOrganizer) {
        this.idOrganizer = idOrganizer;
    }

    public int getIdEvent() {
        return idEvent;
    }

    public void setIdEvent(int idEvent) {
        this.idEvent = idEvent;
    }

    public String getTitleEvent() {
        return TitleEvent;
    }

    public void setTitleEvent(String titleEvent) {
        TitleEvent = titleEvent;
    }

    public String getDescription() { return Description; }

    public void setDescription(String description) {
        Description = description;
    }

    public String getEventLocal() {
        return EventLocal;
    }

    public void setEventLocal(String eventLocal) {
        EventLocal = eventLocal;
    }

    public int getNbrParticipant() {
        return nbrParticipant;
    }

    public void setNbrParticipant(int nbrParticipant) {
        this.nbrParticipant = nbrParticipant;
    }

    public void setState(State state) {
        this.state = state;
    }

    public Date getDateEventDeb() {
        return DateEventDeb;
    }

    public void setDateEventDeb(Date dateEventDeb) {
        DateEventDeb = dateEventDeb;
    }

    public Date getDateEventFin() {
        return DateEventFin;
    }

    public void setDateEventFin(Date dateEventFin) {
        DateEventFin = dateEventFin;
    }

    public String getImgURL() {
        return ImgURL;
    }

    public void setImgURL(String imgURL) {
        ImgURL = imgURL;
    }

    public State getState() { return state; }

    public Event(String titleEvent, String description) {
        TitleEvent = titleEvent;
        Description = description;
    }

    public Event(String titleEvent, String description, Date dateEventDeb, Date dateEventFin) {
        TitleEvent = titleEvent;
        Description = description;
        DateEventDeb = dateEventDeb;
        DateEventFin = dateEventFin;
    }

    public Event(String titleEvent, String description, String imgURL, long idOrganizer, Date dateEventDeb, Date dateEventFin) {
        TitleEvent = titleEvent;
        Description = description;
        ImgURL = imgURL;
        this.idOrganizer = idOrganizer;
        DateEventDeb = dateEventDeb;
        DateEventFin = dateEventFin;
    }

    public Event(int idEvent, String titleEvent, String description, String imgURL, long idOrganizer, String eventLocal, int nbrParticipant, State state, Date dateEventDeb, Date dateEventFin) {
        this.idEvent = idEvent;
        TitleEvent = titleEvent;
        Description = description;
        ImgURL = imgURL;
        this.idOrganizer = idOrganizer;
        EventLocal = eventLocal;
        this.nbrParticipant = nbrParticipant;
        this.state = state;
        DateEventDeb = dateEventDeb;
        DateEventFin = dateEventFin;
    }

    @Override
    public String toString() {
        return "Event{" +
                "idEvent=" + idEvent +
                ", TitleEvent='" + TitleEvent + '\'' +
                ", Description='" + Description + '\'' +
                ", ImgURL='" + ImgURL + '\'' +
                ", idOrganizer=" + idOrganizer +
                ", EventLocal='" + EventLocal + '\'' +
                ", nbrParticipant=" + nbrParticipant +
                ", state=" + state +
                ", DateEventDeb=" + DateEventDeb +
                ", DateEventFin=" + DateEventFin +
                '}';
    }
}
