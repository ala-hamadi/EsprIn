package Utils.Enums;

public enum AdminDepartments {
    Scolarité, Stage, Examen, Financier,
    Service_éléve, Vie_étudiante
}
