package Utils.Enums;

public enum State {
    Connected, Disconnected, Disabled, Deleted, Active
}
