package Utils.Enums;

public enum Roles {
    Admin, Etudiant, Externe, Professeur, Club
}
