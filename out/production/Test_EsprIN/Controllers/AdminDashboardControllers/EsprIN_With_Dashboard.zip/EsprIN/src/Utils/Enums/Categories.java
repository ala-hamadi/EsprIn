package Utils.Enums;

public enum Categories {
  Default,Lost_and_found,Covoiturage,Meme,Suggestion,Demande_exam
}
