package Controllers.Interfaces;

import Modules.User;

public interface BanUserListener {
    public void onBanUser(User user);
}
