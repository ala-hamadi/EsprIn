package Utils;



public class TestMain {
    public static void main(String[] args) {
        System.out.println("bairem.khedhri@esprit.tn".matches("[a-z A-Z]+[/.][a-z]+(@esprit.tn)"));

    }
}
