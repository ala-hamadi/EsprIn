package Controllers.Interfaces;

public interface DeleteListener<T> {
    public void onDelete(T t);
}
