create definer = root@localhost trigger addLike
    before insert
    on `like`
    for each row
    UPDATE post 
set likeNum=likeNum+1
where post.idPost=new.likePost;

