create definer = root@localhost trigger AddReactForum
    before insert
    on `reacted forum`
    for each row
    update forum
set nbrLikesForum=nbrLikesForum+1
where forum.idForum=new.idForum;

