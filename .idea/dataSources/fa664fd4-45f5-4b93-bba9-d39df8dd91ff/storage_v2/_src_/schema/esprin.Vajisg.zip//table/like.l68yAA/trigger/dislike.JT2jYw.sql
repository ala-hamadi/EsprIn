create definer = root@localhost trigger dislike
    before delete
    on `like`
    for each row
    UPDATE post 
set likeNum=likeNum-1
where post.idPost=old.likePost;

