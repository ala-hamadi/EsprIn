create definer = root@localhost trigger dislikeForum
    before delete
    on `reacted forum`
    for each row
    UPDATE forum
set nbrLikesForum=nbrLikesForum-1
where forum.idForum=old.idForum;

